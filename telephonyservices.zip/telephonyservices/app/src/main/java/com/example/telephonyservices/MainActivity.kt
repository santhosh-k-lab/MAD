package com.example.telephonyservices

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.view.LayoutInflater
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.util.Log


class MainActivity : AppCompatActivity() {

    private val permissionRequestCode = 123

    // Declare view variables
    private lateinit var networkOperatorNameTextView: TextView
    private lateinit var phoneTypeTextView: TextView
    private lateinit var networkTypeTextView: TextView
    private lateinit var networkCountryIsoTextView: TextView
    private lateinit var simCountryIsoTextView: TextView
    private lateinit var softwareVersionTextView: TextView
    private lateinit var getTelephonyServiceButton: Button

    // Dynamic permission list based on API level
    private val requiredPermissions by lazy {
        mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.CALL_PHONE
        ).apply {
            // Only add READ_PHONE_NUMBERS on API 26+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                add(Manifest.permission.READ_PHONE_NUMBERS)
            }
        }.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        networkOperatorNameTextView = findViewById(R.id.networkOperatorNameTextView)
        phoneTypeTextView = findViewById(R.id.phoneTypeTextView)
        networkTypeTextView = findViewById(R.id.networkTypeTextView)
        networkCountryIsoTextView = findViewById(R.id.networkCountryIsoTextView)
        simCountryIsoTextView = findViewById(R.id.simCountryIsoTextView)
        softwareVersionTextView = findViewById(R.id.softwareVersionTextView)
        getTelephonyServiceButton = findViewById(R.id.getTelephonyServiceButton)

        // Set button click listener
        getTelephonyServiceButton.setOnClickListener {
            if (hasPermissions()) {
                getTelephonyInfo()
            } else {
                showCustomPermissionDialog()
            }
        }
    }

    private fun hasPermissions(): Boolean {
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun showCustomPermissionDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.permission_dialog, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        val allowButton = dialogView.findViewById<Button>(R.id.allowButton)
        val denyButton = dialogView.findViewById<Button>(R.id.denyButton)

        allowButton.setOnClickListener {
            dialog.dismiss()
            ActivityCompat.requestPermissions(
                this,
                requiredPermissions,
                permissionRequestCode
            )
        }

        denyButton.setOnClickListener {
            dialog.dismiss()
            Toast.makeText(
                this,
                "Permissions are required to access telephony information",
                Toast.LENGTH_SHORT
            ).show()
        }

        dialog.show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == permissionRequestCode) {
            permissions.forEachIndexed { index, permission ->
                val granted = grantResults[index] == PackageManager.PERMISSION_GRANTED
                Log.d("PermissionCheck", "$permission: ${if (granted) "GRANTED" else "DENIED"}")
            }

            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                getTelephonyInfo()
            } else {
                Toast.makeText(
                    this,
                    "Permissions denied. Cannot access telephony information.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    private fun getTelephonyInfo() {
        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        // Network Operator Name
        networkOperatorNameTextView.text = if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            telephonyManager.networkOperatorName ?: "Unknown"
        } else {
            "Permission not granted"
        }

        // Phone Type
        val phoneType = when (telephonyManager.phoneType) {
            TelephonyManager.PHONE_TYPE_GSM -> "GSM"
            TelephonyManager.PHONE_TYPE_CDMA -> "CDMA"
            TelephonyManager.PHONE_TYPE_SIP -> "SIP"
            TelephonyManager.PHONE_TYPE_NONE -> "None"
            else -> "Unknown"
        }
        phoneTypeTextView.text = phoneType

        // Network Type - Avoid using deprecated constants
        val networkType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            when (telephonyManager.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_GPRS,
                TelephonyManager.NETWORK_TYPE_EDGE,
                TelephonyManager.NETWORK_TYPE_CDMA,
                TelephonyManager.NETWORK_TYPE_1xRTT -> "2G"

                TelephonyManager.NETWORK_TYPE_UMTS,
                TelephonyManager.NETWORK_TYPE_EVDO_0,
                TelephonyManager.NETWORK_TYPE_EVDO_A,
                TelephonyManager.NETWORK_TYPE_HSDPA,
                TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_HSPA,
                TelephonyManager.NETWORK_TYPE_EVDO_B,
                TelephonyManager.NETWORK_TYPE_EHRPD,
                TelephonyManager.NETWORK_TYPE_HSPAP -> "3G"

                TelephonyManager.NETWORK_TYPE_LTE -> "4G"

                // Only available in API 29+
                TelephonyManager.NETWORK_TYPE_NR -> "5G"

                else -> "Unknown"
            }
        } else {
            "Android " + Build.VERSION.SDK_INT
        }
        networkTypeTextView.text = networkType

        // Network Country ISO
        val networkCountry = telephonyManager.networkCountryIso ?: ""
        networkCountryIsoTextView.text = if (networkCountry.isEmpty()) "Unknown" else networkCountry

        // SIM Country ISO
        val simCountry = telephonyManager.simCountryIso ?: ""
        simCountryIsoTextView.text = if (simCountry.isEmpty()) "Unknown" else simCountry

        // Software Version
        softwareVersionTextView.text = if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            Build.VERSION.RELEASE
        } else {
            "Permission not granted"
        }

        Toast.makeText(this, "Telephony information updated", Toast.LENGTH_SHORT).show()
    }
}