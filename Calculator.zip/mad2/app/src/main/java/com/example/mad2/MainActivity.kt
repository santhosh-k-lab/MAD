package com.example.mad2

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    private lateinit var inputText: TextView
    private lateinit var buttonGrid: GridLayout
    private lateinit var clearButton: Button

    private var expression = ""

    private val buttons = listOf(
        "7", "8", "9", "/",
        "4", "5", "6", "*",
        "1", "2", "3", "-",
        "0", ".", "=", "+",
        "sin", "cos", "tan", "log",
        "sqrt", "pow", "mod", "C"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputText = findViewById(R.id.inputText)
        buttonGrid = findViewById(R.id.buttonGrid)
        clearButton = findViewById(R.id.clearButton)

        // Dynamically add buttons
        for (label in buttons) {
            val btn = Button(this).apply {
                text = label
                textSize = 16f
                setBackgroundColor(0xFF800080.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener { handleInput(label) }
            }
            buttonGrid.addView(btn)
        }

        clearButton.setOnClickListener {
            expression = ""
            inputText.text = ""
        }
    }

    private fun handleInput(input: String) {
        when (input) {
            "=" -> evaluateExpression()
            "C" -> {
                expression = ""
                inputText.text = ""
            }
            "sin", "cos", "tan", "log", "sqrt" -> {
                try {
                    val num = expression.toDouble()
                    val result = when (input) {
                        "sin" -> sin(Math.toRadians(num))
                        "cos" -> cos(Math.toRadians(num))
                        "tan" -> tan(Math.toRadians(num))
                        "log" -> log10(num)
                        "sqrt" -> sqrt(num)
                        else -> 0.0
                    }
                    inputText.text = "$input($num)\n= $result"
                    expression = result.toString()
                } catch (e: Exception) {
                    inputText.text = "Error"
                    expression = ""
                }
            }
            else -> {
                expression += input
                inputText.text = expression
            }
        }
    }

    private fun evaluateExpression() {
        try {
            val result = when {
                expression.contains("+") -> {
                    val (a, b) = expression.split("+")
                    a.toDouble() + b.toDouble()
                }
                expression.contains("-") -> {
                    val (a, b) = expression.split("-")
                    a.toDouble() - b.toDouble()
                }
                expression.contains("*") -> {
                    val (a, b) = expression.split("*")
                    a.toDouble() * b.toDouble()
                }
                expression.contains("/") -> {
                    val (a, b) = expression.split("/")
                    a.toDouble() / b.toDouble()
                }
                expression.contains("mod") -> {
                    val (a, b) = expression.split("mod")
                    a.toDouble() % b.toDouble()
                }
                expression.contains("pow") -> {
                    val (a, b) = expression.split("pow")
                    a.toDouble().pow(b.toDouble())
                }
                else -> expression.toDouble()
            }
            inputText.text = "$expression\n= $result"
            expression = result.toString()
        } catch (e: Exception) {
            inputText.text = "Error"
            expression = ""
        }
    }
}
