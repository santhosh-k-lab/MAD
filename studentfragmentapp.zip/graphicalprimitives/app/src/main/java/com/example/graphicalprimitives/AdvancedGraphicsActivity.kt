package com.example.graphicalprimitives

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class AdvancedGraphicsActivity : AppCompatActivity() {

    private lateinit var graphicsView: AdvancedGraphicsView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_advanced_graphics)

        graphicsView = findViewById(R.id.advancedGraphicsView)

        // Setup buttons for shape selection
        findViewById<Button>(R.id.btnCircle).setOnClickListener {
            graphicsView.setCurrentShape(AdvancedGraphicsView.Shape.CIRCLE)
        }

        findViewById<Button>(R.id.btnRectangle).setOnClickListener {
            graphicsView.setCurrentShape(AdvancedGraphicsView.Shape.RECTANGLE)
        }

        findViewById<Button>(R.id.btnEllipse).setOnClickListener {
            graphicsView.setCurrentShape(AdvancedGraphicsView.Shape.ELLIPSE)
        }

        findViewById<Button>(R.id.btnSquare).setOnClickListener {
            graphicsView.setCurrentShape(AdvancedGraphicsView.Shape.SQUARE)
        }

        findViewById<Button>(R.id.btnLine).setOnClickListener {
            graphicsView.setCurrentShape(AdvancedGraphicsView.Shape.LINE)
        }

        findViewById<Button>(R.id.btnText).setOnClickListener {
            graphicsView.setCurrentShape(AdvancedGraphicsView.Shape.TEXT)
        }
    }
}