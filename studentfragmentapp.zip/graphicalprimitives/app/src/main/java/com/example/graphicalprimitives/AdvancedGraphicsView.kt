package com.example.graphicalprimitives

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min

class AdvancedGraphicsView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Shape {
        CIRCLE, RECTANGLE, ELLIPSE, SQUARE, LINE, TEXT
    }

    private var currentShape = Shape.CIRCLE
    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var isDrawing = false

    private val shapes = mutableListOf<DrawnShape>()

    private val paint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = Color.RED
    }

    private val textPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = Color.BLACK
        textSize = 40f
    }

    fun setCurrentShape(shape: Shape) {
        currentShape = shape
        when (shape) {
            Shape.CIRCLE -> paint.color = Color.RED
            Shape.RECTANGLE -> paint.color = Color.GREEN
            Shape.ELLIPSE -> paint.color = Color.MAGENTA
            Shape.SQUARE -> paint.color = Color.BLUE
            Shape.LINE -> {
                paint.color = Color.BLACK
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 8f
            }
            Shape.TEXT -> {
                paint.style = Paint.Style.FILL
                paint.color = Color.BLACK
            }
        }

        if (shape != Shape.LINE) {
            paint.style = Paint.Style.FILL
        }

        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                endX = event.x
                endY = event.y
                isDrawing = true
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDrawing) {
                    endX = event.x
                    endY = event.y
                    invalidate()
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                if (isDrawing) {
                    endX = event.x
                    endY = event.y

                    val newShape = when (currentShape) {
                        Shape.CIRCLE -> CircleShape(startX, startY, calculateRadius(), Paint(paint))
                        Shape.RECTANGLE -> RectangleShape(startX, startY, endX, endY, Paint(paint))
                        Shape.ELLIPSE -> EllipseShape(startX, startY, endX, endY, Paint(paint))
                        Shape.SQUARE -> {
                            val size = min(abs(endX - startX), abs(endY - startY))
                            val newEndX = if (endX > startX) startX + size else startX - size
                            val newEndY = if (endY > startY) startY + size else startY - size
                            RectangleShape(startX, startY, newEndX, newEndY, Paint(paint))
                        }
                        Shape.LINE -> LineShape(startX, startY, endX, endY, Paint(paint))
                        Shape.TEXT -> TextShape(startX, startY, "Sample Text", Paint(textPaint))
                    }

                    shapes.add(newShape)
                    isDrawing = false
                    invalidate()
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }

    private fun calculateRadius(): Float {
        val dx = endX - startX
        val dy = endY - startY
        return min(abs(dx), abs(dy)) / 2
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Draw background
        canvas.drawColor(Color.YELLOW)

        // Draw all saved shapes
        for (shape in shapes) {
            shape.draw(canvas)
        }

        // Draw the current shape being created
        if (isDrawing) {
            when (currentShape) {
                Shape.CIRCLE -> {
                    val radius = calculateRadius()
                    canvas.drawCircle(startX, startY, radius, paint)
                }
                Shape.RECTANGLE -> {
                    val rect = RectF(
                        minOf(startX, endX),
                        minOf(startY, endY),
                        maxOf(startX, endX),
                        maxOf(startY, endY)
                    )
                    canvas.drawRect(rect, paint)
                }
                Shape.ELLIPSE -> {
                    val rect = RectF(
                        minOf(startX, endX),
                        minOf(startY, endY),
                        maxOf(startX, endX),
                        maxOf(startY, endY)
                    )
                    canvas.drawOval(rect, paint)
                }
                Shape.SQUARE -> {
                    val size = min(abs(endX - startX), abs(endY - startY))
                    val newEndX = if (endX > startX) startX + size else startX - size
                    val newEndY = if (endY > startY) startY + size else startY - size

                    val rect = RectF(
                        minOf(startX, newEndX),
                        minOf(startY, newEndY),
                        maxOf(startX, newEndX),
                        maxOf(startY, newEndY)
                    )
                    canvas.drawRect(rect, paint)
                }
                Shape.LINE -> {
                    canvas.drawLine(startX, startY, endX, endY, paint)
                }
                Shape.TEXT -> {
                    canvas.drawText("Sample Text", startX, startY, textPaint)
                }
            }
        }
    }

    // Abstract shape for drawing
    private abstract class DrawnShape(protected val paint: Paint) {
        abstract fun draw(canvas: Canvas)
    }

    // Concrete shape implementations
    private class CircleShape(
        private val centerX: Float,
        private val centerY: Float,
        private val radius: Float,
        paint: Paint
    ) : DrawnShape(paint) {
        override fun draw(canvas: Canvas) {
            canvas.drawCircle(centerX, centerY, radius, paint)
        }
    }

    private class RectangleShape(
        private val startX: Float,
        private val startY: Float,
        private val endX: Float,
        private val endY: Float,
        paint: Paint
    ) : DrawnShape(paint) {
        override fun draw(canvas: Canvas) {
            val rect = RectF(
                minOf(startX, endX),
                minOf(startY, endY),
                maxOf(startX, endX),
                maxOf(startY, endY)
            )
            canvas.drawRect(rect, paint)
        }
    }

    private class EllipseShape(
        private val startX: Float,
        private val startY: Float,
        private val endX: Float,
        private val endY: Float,
        paint: Paint
    ) : DrawnShape(paint) {
        override fun draw(canvas: Canvas) {
            val rect = RectF(
                minOf(startX, endX),
                minOf(startY, endY),
                maxOf(startX, endX),
                maxOf(startY, endY)
            )
            canvas.drawOval(rect, paint)
        }
    }

    private class LineShape(
        private val startX: Float,
        private val startY: Float,
        private val endX: Float,
        private val endY: Float,
        paint: Paint
    ) : DrawnShape(paint) {
        override fun draw(canvas: Canvas) {
            canvas.drawLine(startX, startY, endX, endY, paint)
        }
    }

    private class TextShape(
        private val x: Float,
        private val y: Float,
        private val text: String,
        paint: Paint
    ) : DrawnShape(paint) {
        override fun draw(canvas: Canvas) {
            canvas.drawText(text, x, y, paint)
        }
    }
}
