package com.example.graphicalprimitives

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class CustomShapeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
    }

    private val textPaint = Paint().apply {
        isAntiAlias = true
        color = Color.BLACK
        textSize = 40f
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Background
        canvas.drawColor(Color.YELLOW)

        val cellWidth = width / 2f
        val cellHeight = height / 2f

        // Draw Circle
        paint.color = Color.RED
        canvas.drawCircle(cellWidth * 0.5f, cellHeight * 0.5f, cellWidth * 0.3f, paint)
        canvas.drawText("Circle", cellWidth * 0.5f, cellHeight * 0.9f, textPaint)

        // Draw Rectangle
        paint.color = Color.GREEN
        val rectF = RectF(cellWidth * 1.2f, cellHeight * 0.2f, cellWidth * 1.8f, cellHeight * 0.8f)
        canvas.drawRect(rectF, paint)
        canvas.drawText("Rectangle", cellWidth * 1.5f, cellHeight * 0.9f, textPaint)

        // Draw Square
        paint.color = Color.BLUE
        val squareSize = cellWidth * 0.6f
        val squareLeft = cellWidth * 0.5f - squareSize * 0.5f
        val squareTop = cellHeight * 1.2f
        canvas.drawRect(squareLeft, squareTop, squareLeft + squareSize, squareTop + squareSize, paint)
        canvas.drawText("Square", cellWidth * 0.5f, cellHeight * 1.9f, textPaint)

        // Draw Line
        paint.color = Color.BLACK
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 8f
        canvas.drawLine(cellWidth * 1.5f, cellHeight * 1.2f, cellWidth * 1.5f, cellHeight * 1.8f, paint)
        canvas.drawText("Line", cellWidth * 1.5f, cellHeight * 1.9f, textPaint)
    }
}