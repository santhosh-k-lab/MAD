package com.example.graphicalprimitives

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DrawingBoardActivity : AppCompatActivity() {

    private lateinit var drawingBoardView: DrawingBoardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawing_board)

        drawingBoardView = findViewById(R.id.drawingBoardView)

        // Shape buttons
        findViewById<Button>(R.id.btnCircle).setOnClickListener {
            drawingBoardView.setCurrentShape(DrawingBoardView.ShapeType.CIRCLE)
        }

        findViewById<Button>(R.id.btnEllipse).setOnClickListener {
            drawingBoardView.setCurrentShape(DrawingBoardView.ShapeType.ELLIPSE)
        }

        findViewById<Button>(R.id.btnRect).setOnClickListener {
            drawingBoardView.setCurrentShape(DrawingBoardView.ShapeType.RECTANGLE)
        }

        findViewById<Button>(R.id.btnLine).setOnClickListener {
            drawingBoardView.setCurrentShape(DrawingBoardView.ShapeType.LINE)
        }

        // Color buttons
        findViewById<Button>(R.id.btnRed).setOnClickListener {
            drawingBoardView.setCurrentColor(Color.RED)
        }

        findViewById<Button>(R.id.btnGreen).setOnClickListener {
            drawingBoardView.setCurrentColor(Color.GREEN)
        }

        findViewById<Button>(R.id.btnBlue).setOnClickListener {
            drawingBoardView.setCurrentColor(Color.BLUE)
        }

        // Clear button
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            drawingBoardView.clearCanvas()
        }
    }
}