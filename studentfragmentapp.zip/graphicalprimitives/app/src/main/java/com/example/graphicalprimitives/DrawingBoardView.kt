package com.example.graphicalprimitives

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min

class DrawingBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class ShapeType {
        CIRCLE, ELLIPSE, RECTANGLE, LINE
    }

    private var currentShapeType = ShapeType.CIRCLE
    private var currentColor = Color.RED
    private var isDrawing = false
    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f

    private val shapes = mutableListOf<Shape>()

    private val paint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = currentColor
        strokeWidth = 5f
    }

    fun setCurrentShape(shapeType: ShapeType) {
        currentShapeType = shapeType
    }

    fun setCurrentColor(color: Int) {
        currentColor = color
        paint.color = color
    }

    fun clearCanvas() {
        shapes.clear()
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                endX = event.x
                endY = event.y
                isDrawing = true
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDrawing) {
                    endX = event.x
                    endY = event.y
                    invalidate()
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                if (isDrawing) {
                    endX = event.x
                    endY = event.y

                    val shapePaint = Paint(paint)
                    shapePaint.color = currentColor

                    val shape = when (currentShapeType) {
                        ShapeType.CIRCLE -> {
                            val distance = calculateDistance(startX, startY, endX, endY)
                            CircleShape(startX, startY, distance, shapePaint)
                        }
                        ShapeType.ELLIPSE -> {
                            EllipseShape(startX, startY, endX, endY, shapePaint)
                        }
                        ShapeType.RECTANGLE -> {
                            RectangleShape(startX, startY, endX, endY, shapePaint)
                        }
                        ShapeType.LINE -> {
                            val linePaint = Paint(shapePaint).apply {
                                style = Paint.Style.STROKE
                            }
                            LineShape(startX, startY, endX, endY, linePaint)
                        }
                    }

                    shapes.add(shape)
                    isDrawing = false
                    invalidate()
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }

    private fun calculateDistance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Draw yellow background
        canvas.drawColor(Color.YELLOW)

        // Draw all shapes
        for (shape in shapes) {
            shape.draw(canvas)
        }

        // Draw current shape being created
        if (isDrawing) {
            val tempPaint = Paint(paint)
            tempPaint.color = currentColor

            when (currentShapeType) {
                ShapeType.CIRCLE -> {
                    val distance = calculateDistance(startX, startY, endX, endY)
                    canvas.drawCircle(startX, startY, distance, tempPaint)
                }
                ShapeType.ELLIPSE -> {
                    val rect = RectF(
                        minOf(startX, endX),
                        minOf(startY, endY),
                        maxOf(startX, endX),
                        maxOf(startY, endY)
                    )
                    canvas.drawOval(rect, tempPaint)
                }
                ShapeType.RECTANGLE -> {
                    val rect = RectF(
                        minOf(startX, endX),
                        minOf(startY, endY),
                        maxOf(startX, endX),
                        maxOf(startY, endY)
                    )
                    canvas.drawRect(rect, tempPaint)
                }
                ShapeType.LINE -> {
                    val linePaint = Paint(tempPaint).apply {
                        style = Paint.Style.STROKE
                    }
                    canvas.drawLine(startX, startY, endX, endY, linePaint)
                }
            }
        }
    }

    // Abstract shape interface
    private interface Shape {
        fun draw(canvas: Canvas)
    }

    // Shape implementations
    private class CircleShape(
        private val centerX: Float,
        private val centerY: Float,
        private val radius: Float,
        private val paint: Paint
    ) : Shape {
        override fun draw(canvas: Canvas) {
            canvas.drawCircle(centerX, centerY, radius, paint)
        }
    }

    private class EllipseShape(
        private val startX: Float,
        private val startY: Float,
        private val endX: Float,
        private val endY: Float,
        private val paint: Paint
    ) : Shape {
        override fun draw(canvas: Canvas) {
            val rect = RectF(
                minOf(startX, endX),
                minOf(startY, endY),
                maxOf(startX, endX),
                maxOf(startY, endY)
            )
            canvas.drawOval(rect, paint)
        }
    }

    private class RectangleShape(
        private val startX: Float,
        private val startY: Float,
        private val endX: Float,
        private val endY: Float,
        private val paint: Paint
    ) : Shape {
        override fun draw(canvas: Canvas) {
            val rect = RectF(
                minOf(startX, endX),
                minOf(startY, endY),
                maxOf(startX, endX),
                maxOf(startY, endY)
            )
            canvas.drawRect(rect, paint)
        }
    }

    private class LineShape(
        private val startX: Float,
        private val startY: Float,
        private val endX: Float,
        private val endY: Float,
        private val paint: Paint
    ) : Shape {
        override fun draw(canvas: Canvas) {
            canvas.drawLine(startX, startY, endX, endY, paint)
        }
    }
}