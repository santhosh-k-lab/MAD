package com.example.graphicalprimitives

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find buttons
        val basicShapesButton = findViewById<Button>(R.id.btnBasicShapes)
        val advancedShapesButton = findViewById<Button>(R.id.btnAdvancedShapes)
        val drawingBoardButton = findViewById<Button>(R.id.btnDrawingBoard)

        // Set click listeners
        basicShapesButton.setOnClickListener {
            // Show the basic shapes demonstration (same activity)
            val customShapeView = findViewById<CustomShapeView>(R.id.customShapeView)
            customShapeView.visibility = android.view.View.VISIBLE
            findViewById<android.view.View>(R.id.mainButtons).visibility = android.view.View.GONE
        }

        advancedShapesButton.setOnClickListener {
            // Navigate to Advanced Graphics Activity
            val intent = Intent(this, AdvancedGraphicsActivity::class.java)
            startActivity(intent)
        }

        drawingBoardButton.setOnClickListener {
            // Navigate to Drawing Board Activity
            val intent = Intent(this, DrawingBoardActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
        // Check if we're showing shapes
        val customShapeView = findViewById<CustomShapeView>(R.id.customShapeView)
        if (customShapeView.visibility == android.view.View.VISIBLE) {
            // Return to main menu
            customShapeView.visibility = android.view.View.GONE
            findViewById<android.view.View>(R.id.mainButtons).visibility = android.view.View.VISIBLE
        } else {
            super.onBackPressed()
        }
    }
}