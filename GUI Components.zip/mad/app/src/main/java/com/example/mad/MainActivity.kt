package com.example.mad

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var labelText: TextView
    private lateinit var fontSizeButton: Button
    private lateinit var fontColorButton: Button
    private lateinit var bgColorButton: Button
    private lateinit var rootLayout: LinearLayout

    private var fontSize = 20f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        labelText = findViewById(R.id.labelText)
        fontSizeButton = findViewById(R.id.fontSizeButton)
        fontColorButton = findViewById(R.id.fontColorButton)
        bgColorButton = findViewById(R.id.bgColorButton)
        rootLayout = findViewById(R.id.rootLayout)

        fontSizeButton.setOnClickListener {
            fontSize += 4f
            if (fontSize > 40f) fontSize = 20f
            labelText.textSize = fontSize
            Toast.makeText(this, "Font size set to ${fontSize.toInt()}sp", Toast.LENGTH_SHORT).show()
        }

        fontColorButton.setOnClickListener {
            val color = getRandomColor()
            labelText.setTextColor(color)
            Toast.makeText(this, "Font color changed!", Toast.LENGTH_SHORT).show()
        }

        bgColorButton.setOnClickListener {
            val color = getRandomColor()
            rootLayout.setBackgroundColor(color)
            Toast.makeText(this, "Background color changed!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getRandomColor(): Int {
        val r = Random.nextInt(0, 256)
        val g = Random.nextInt(0, 256)
        val b = Random.nextInt(0, 256)
        return Color.rgb(r, g, b)
    }
}
